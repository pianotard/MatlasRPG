import java.util.Scanner;

public class Main {

    public static void main(String[] args) { 
        System.out.println("Welcome to image rotator!");
        System.out.println("Please key in your working directory (default: src)");
        Scanner sc = new Scanner(System.in);
        String directory = sc.next() + "/";
        System.out.println("360? Y / N");
        String response = sc.next();
        if (response.toLowerCase().equals("y")) {
            System.out.println("Please key in your file name (include extension):");
            String input = sc.next();
            Rotator rotator = new Rotator(directory + input);
            System.out.println("Type anything to start..");
            sc.nextLine();
            String output = input.substring(0, input.length() - 4);
            for (int i = 0; i < 360; i++) {
                String name = directory + output + "_" + i + ".png";
                rotator.write(rotator.rotate(i), name);
                System.out.println("Written '" + name + "'");
            }
            System.out.println("Finished writing!");
            return;
        }
        System.out.println("How many images?");
        int num = sc.nextInt();
        Rotator[] rotators = new Rotator[num];
        String[] inputs = new String[num];
        for (int i = 0; i < num; i++) {
            System.out.println("Please key in file name " + (i + 1) + " (include extension):");
            inputs[i] = sc.next();
            rotators[i] = new Rotator(directory + inputs[i]);
        }
        System.out.println("How many degrees clockwise?");
        int degree = sc.nextInt();
        for (int i = 0; i < num; i++) {
            String output = inputs[i].substring(0, inputs[i].length() - 4);
            String name = directory + output + "_" + degree + ".png";
            rotators[i].write(rotators[i].rotate(degree), name);
            System.out.println("Written '" + name + "'");
        }
        System.out.println("Finished writing!");
    }
}
