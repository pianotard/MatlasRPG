import java.util.Scanner;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Cropper {

    BufferedImage source;

    public Cropper(String inputPath) {
        try {
            this.source = ImageIO.read(new File(inputPath));
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public static void write(BufferedImage image, String outputPath) {
        File outputFile = new File(outputPath);
        try {
            ImageIO.write(image, "png", outputFile);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public static void main(String[] args) { 
        System.out.println("Welcome to image cropper!");
        System.out.println("Please key in your working directory (default: src)");
        Scanner sc = new Scanner(System.in);
        String directory = sc.next() + "/";
        System.out.println("Please key in file name (include extension):");
        String input = sc.next();
        Cropper cropper = new Cropper(directory + input);
        System.out.println("Cropper created! Please enter original dimensions (w [SPACE] h):");
        int width = sc.nextInt();
        int height = sc.nextInt();
        System.out.println("Proceeding to do L-R slicing.. Please enter number of slices to output:");
        int slices = sc.nextInt();
        int dy = height / slices;
        System.out.println("Slices initialised. Press any key to start");
        sc.nextLine();
        String output = input.substring(0, input.length() - 4);
        for (int i = 0; i < slices; i++) {
            String name = "out/" + output + "_" + i + ".png";
            Cropper.write(cropper.crop(0, dy * i, width, height - dy * i), name);
            System.out.println("Written '" + name + "'");
        }
        System.out.println("Finished writing!");
    }

    public BufferedImage crop(int x, int y, int width, int height) {
        try {
            BufferedImage transparent = ImageIO.read(new File("src/transparent.png"));
            BufferedImage cropped = this.source.getSubimage(x, y, width, height);
            Graphics2D g2d = transparent.createGraphics();
            g2d.setComposite(
                    AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
            g2d.drawImage(cropped, x, y, null);
            g2d.dispose();
            return transparent;
        } catch (IOException e) {
            System.err.println(e);
        }
        return null;
    }
}
